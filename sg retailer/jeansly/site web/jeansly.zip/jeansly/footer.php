<br><br><footer class="footer">

   <section class="box-container">



      <div class="box">
         <h3>contact info</h3>
         <p> <i class="fas fa-phone"></i> 26877946</p>

         <p> <i class="fas fa-envelope"></i> jeansly4business@gmail.com </p>
         <p> <i class="fas fa-map-marker-alt"></i> TUNISIA,SOUSSE </p>
      </div>

      <div class="box">
         <h3>Nos pages sociaux</h3>
         <a href="https://www.facebook.com/sarra.sg.50"> <i class="fab fa-facebook-f"></i> facebook </a>
         
         <a href="https://www.instagram.com/jeansly.tn/"> <i class="fab fa-instagram"></i> instagram </a>
         
      </div>

   </section>

   <p class="credit"> &copy; created @ <?= date('Y'); ?> by <a href="https://www.instagram.com/rafed_tb/">mr. Rafed</a> | all rights reserved! @jeans'ly </p>

</footer>