<?php

$db_name = "mysql:host=sql108.epizy.com;dbname=epiz_32177739_sarah";
$username = "epiz_32177739";
$password = "85iSNEYPnXEO";

$conn = new PDO($db_name, $username, $password);

?>